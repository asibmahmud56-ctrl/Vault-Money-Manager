# Vault — Android APK project

This project wraps the Vault HTML app in an Android WebView.

## Build an APK using GitHub Actions (phone-friendly)

1. Extract this ZIP.
2. Create a new GitHub repository and upload all files/folders from this project.
3. Open the repository's **Actions** tab.
4. Select **Build Vault APK** and tap **Run workflow**.
5. When the run finishes, open it and download the **Vault-debug-apk** artifact.
6. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

The workflow builds a debug APK. It is suitable for testing and personal installation, not a Play Store release. A release APK needs signing configuration and a private keystore.

## Notes
- App data is stored locally in the WebView browser storage.
- Use the app's Backup button regularly before clearing app data or uninstalling.
- This is a WebView wrapper, not a native rewrite of every screen.
